using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewPaused", menuName = "Paused")]
public class Paused : ScriptableObject
{
    public bool isPaused;
}
