using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewBattleResults", menuName = "Results")]
public class BattleResults : ScriptableObject
{
    public int damAmount;
}
