using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PlayerPosition", menuName = "Positions")]
public class VectorValue : ScriptableObject
{
    public Vector2 intitalValue;
}
