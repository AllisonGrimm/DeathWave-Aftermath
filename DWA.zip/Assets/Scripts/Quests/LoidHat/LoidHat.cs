using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "LH", menuName = "Quest/LH")]

public class LoidHat : ScriptableObject
{
    public bool started;
    public bool second;
    public bool fin;
}
